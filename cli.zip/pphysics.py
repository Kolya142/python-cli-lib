from random import random, randint
from typing import List
import time

import keyboard

import cli
cli.init()
world: List['Entity'] = []
# gravity = 0.001
# frames = 500
# ricochet_force = -1
# air_stop = 0.999

gravity = 0.0001
frames = 10000
ricochet_force = -1
air_stop = 1


class Entity:
    x: float
    y: float
    vx: float
    vy: float
    c: str
    col: object
    static: bool
    ricochet: bool

    def __init__(self, x, y, c, col, *, is_static: bool = False, ricochet: bool = False, vx: float = 0, vy: float = 0):
        self.x = x
        self.y = y
        self.c = c
        self.col = col
        self.vx = vx
        self.vy = vy
        self.static = is_static
        self.ricochet = ricochet

    def update(self):
        if not self.static:
            x = self.x
            y = self.y
            self.x += self.vx
            self.y += self.vy
            for obj in world:
                if obj is self:
                    continue
                if int(self.x) == int(obj.x) and int(self.y) == int(obj.y):
                    if abs(self.vx) > abs(self.vy):
                        self.x = x
                        if obj.ricochet:
                            self.vx *= ricochet_force
                        else:
                            self.vx *= .3
                    else:
                        self.y = y
                        if obj.ricochet:
                            self.vy *= ricochet_force
                        else:
                            self.vy *= .3
            self.vy *= air_stop
            self.vx *= air_stop
            self.vy += gravity
            if self.x < 0:
                self.x = cli.size[0] - self.x
            if self.y < 0:
                self.y = cli.size[1] - self.y
            if self.x > cli.size[0]+1:
                self.x = self.x - cli.size[0]
            if self.y > cli.size[1]+1:
                self.y = self.y - cli.size[1]

        cli.rect(int(self.x), int(self.y), 0, 0, self.c, self.col, (0, 0, 0))


world.append(Entity(30, 2, '&', [255, 0, 0], vx=-0.1))
world.append(Entity(20, 6, '&', [200, 150, 150], vx=-0.1))
world.append(Entity(10, 1, '&', [150, 250, 100], vx=0.1))
for _ in range(30):
    world.append(
        Entity(randint(0, cli.size[0]), randint(0, cli.size[1]), '&',
               [randint(0, 255), randint(0, 255), randint(0, 255)], vx=randint(-15, 15)/5,
               vy=randint(-5, 5)/5, ricochet=True))
world.append(Entity(9, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(10, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(11, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(12, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(13, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(14, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(15, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(16, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(17, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(18, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(19, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(20, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(21, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(22, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(23, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(24, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(25, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(26, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
world.append(Entity(27, 7, '*', [255, 255, 0], is_static=True, ricochet=True))
world.append(Entity(28, 7, '*', [255, 0, 0], is_static=True, ricochet=True))
for i in range(cli.size[0]):
    world.append(Entity(i, cli.size[1]-1, '*', [255, int(i/cli.size[0]*255), 0], is_static=True, ricochet=True))
t = time.time()

while True:
    if time.time() - t >= 1/frames:

        cli.clear()
        for ent in world:
            # cli.blit_text(int(ent.x), int(ent.y-1), f'{round(ent.x)},{round(ent.y)}')
            ent.update()
            t = time.time()
    if keyboard.is_pressed('`'):
        command = cli.input_menu()
        if len(command.split()) == 2 and command.split()[0] in ("frames", "grav", "air", "rich"):
            var = command.split()[0]
            match var:
                case "frames":
                    frames = float(command.split()[1])
                case "grav":
                    gravity = float(command.split()[1])
                case "air":
                    air_stop = float(command.split()[1])
                case "rich":
                    ricochet_force = float(command.split()[1])

    cli.update()
    cli.draw()
