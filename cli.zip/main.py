prog = 3  # drawing - 0, test shader - 1, clock - 2, physics - 3

match prog:
    case 0:
        import drawing
    case 1:
        import test
    case 2:
        import clock
    case 3:
        import pphysics
    case _:
        raise ValueError
